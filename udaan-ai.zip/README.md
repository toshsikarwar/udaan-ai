# υԃааɴ AI - Your Personal AI Assistant 💡

An intelligent assistant powered by OpenAI that can:
- Answer any question
- Write scripts, stories, poems
- Help you with coding
- Motivate you with quotes

## 🧠 How to Run

```bash
pip install -r requirements.txt
export OPENAI_API_KEY=your-api-key-here
python app.py
```

Then open your browser at: http://localhost:5000

---

© 2025 ʙє υԃааɴ